declare module "@salesforce/resourceUrl/DiabetesCareAssessment" {
    var DiabetesCareAssessment: string;
    export default DiabetesCareAssessment;
}
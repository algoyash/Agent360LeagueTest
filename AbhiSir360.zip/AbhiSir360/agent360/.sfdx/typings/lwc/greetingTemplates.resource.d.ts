declare module "@salesforce/resourceUrl/greetingTemplates" {
    var greetingTemplates: string;
    export default greetingTemplates;
}
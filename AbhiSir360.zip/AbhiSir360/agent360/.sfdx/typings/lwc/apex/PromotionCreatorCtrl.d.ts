declare module "@salesforce/apex/PromotionCreatorCtrl.getProducts" {
  export default function getProducts(param: {type: any, pageNumber: any, locatorParam: any}): Promise<any>;
}
declare module "@salesforce/apex/PromotionCreatorCtrl.getRetailStores" {
  export default function getRetailStores(param: {accountId: any}): Promise<any>;
}
declare module "@salesforce/apex/PromotionCreatorCtrl.savePromotion" {
  export default function savePromotion(param: {promotionDataJson: any}): Promise<any>;
}
